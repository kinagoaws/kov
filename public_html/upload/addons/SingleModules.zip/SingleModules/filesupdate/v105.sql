
INSERT INTO `st_addons` (`id`, `addon_name`, `uuid`, `version`, `activated`, `image`, `path`, `purchase_code`, `date_created`, `date_modified`, `ip_address`) VALUES
(null, 'Single app', 'DXpn3kxHj8oVc64YvsHDTm2n6srn87gmcA2ZqXhgxI3dZ0cvYHh6UE8YXZQW/Xr2Mzf7svb3dPWaqg==', '1.0.5', 1, 'singleapp_banner.png', 'upload/all', '', now(), now(), '127.0.0.1');

COMMIT;