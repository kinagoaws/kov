UPDATE  st_addons SET version="1.0.5"
WHERE uuid = "DXpn3kxHj8oVc64YvsHDTm2n6srn87gmcA2ZqXhgxI3dZ0cvYHh6UE8YXZQW/Xr2Mzf7svb3dPWaqg==";
COMMIT;