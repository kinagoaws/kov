INSERT INTO `st_addons` ( `addon_name`, `uuid`, `version`, `activated`, `image`, `path`, `purchase_code`, `date_created`, `date_modified`, `ip_address`) VALUES
('Karenderia Kitchen App', 'REXUdMpCw9wpB/lbEEmKvpP/DBjUd3k8yM9Ax9AJCC6XW/M6RRmTfJb+BQdqC8y6lMeL3etu45KNBFW2ybOSNGf23pDCtg==', '1.0.1', 1, 'kitchen_banner.png', 'upload/all', '', NULL, NULL, '');
COMMIT;