
INSERT INTO `st_addons` (`id`, `addon_name`, `uuid`, `version`, `activated`, `image`, `path`, `purchase_code`, `date_created`, `date_modified`, `ip_address`) VALUES
(null, 'Single Mobile App', 'Jg4VxUMHOMb+LmLX6n25mae/LK56BekNPAwm/8UMuFWAbdME9MW2b7i9OScUzEo32xbOMFXt416romMxR7RZexk=', '1.0.3', 1, 'singlemobileapp_banner.png', 'upload/all', '', now(), now(), '127.0.0.1');

COMMIT;