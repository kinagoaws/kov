INSERT INTO `st_addons` ( `addon_name`, `uuid`, `version`, `activated`, `image`, `path`, `purchase_code`, `date_created`, `date_modified`, `ip_address`) VALUES
('Karenderia MenuClone', 'i2kkS2kIsYH0q21c1uySLhBIlymBeXMk2jjaS81Lc1O01U2wz5xYFG53AaO0f033PuPh/9NSSB6U99NKEWYF8FLC1I0=', '1.0.1', 1, 'menuclone_banner.png', 'upload/all', '', NULL, NULL, '');
COMMIT;

COMMIT;