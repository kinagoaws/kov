
INSERT INTO `st_addons` (`id`, `addon_name`, `uuid`, `version`, `activated`, `image`, `path`, `purchase_code`, `date_created`, `date_modified`, `ip_address`) VALUES
(null, 'Driver app', '7EewaLXhXX50fWBCC+Gg3r4M4UpUwi6CWtH+y/GHPjC6bcd66lXfETwz7nO/5HYmkcmNURCAov8Vgg==', '1.0.3', 1, 'rider_banner.png', 'upload/all', '', now(), now(), '127.0.0.1');

COMMIT;