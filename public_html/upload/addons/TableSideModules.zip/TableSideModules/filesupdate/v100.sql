
INSERT INTO `st_addons` ( `addon_name`, `uuid`, `version`, `activated`, `image`, `path`, `purchase_code`, `date_created`, `date_modified`, `ip_address`) VALUES
('Karenderia Tableside Ordering', 'FeydCQNGZ2mMjstYltzY4YptyfWbMIFUubFTb0owcekIp8z3Z0mRpCJmYAr44fovppwEFw0gSrlRHEoJwxfEMoUUfehIQKdhX3FUtHY=', '1.0.0', 1, 'tableside_banner.png', 'upload/all', '', NULL, NULL, '');

COMMIT;