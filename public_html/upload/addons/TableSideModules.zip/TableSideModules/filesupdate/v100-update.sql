UPDATE  st_addons SET version="1.0.0"
WHERE uuid = "FeydCQNGZ2mMjstYltzY4YptyfWbMIFUubFTb0owcekIp8z3Z0mRpCJmYAr44fovppwEFw0gSrlRHEoJwxfEMoUUfehIQKdhX3FUtHY=";
COMMIT;