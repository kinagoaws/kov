<?php
class EventController extends CController {
    public function actionIndex() {
        echo "Manage Events Here.";
    }

    public function actionCreate() {
        echo "Create New Event Here.";
    }
}
?>