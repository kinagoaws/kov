<?php
class DefaultController extends CController {
    public function actionIndex() {
        echo "Event Tickets Module is working!";
    }
}
?>