<?php
class EventController extends CController {
    public function actionIndex() {
        echo "Events action is working.";
    }

    public function actionCreate() {
        echo "Create event action is working.";
    }
}
?>